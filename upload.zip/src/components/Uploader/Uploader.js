import { useState } from "react";
import "./Uploader.css";
import { BsPlusCircleDotted } from "react-icons/bs";
import { FiUploadCloud } from "react-icons/fi";

export default function Uploader() {
  const handleFileUpload = (event, isqr) => {
    const file = event.target.files[0];
    const formData = new FormData();
    formData.append("file", file);
    formData.append("media_type", "image");
    fetch("https://api.dev.apex.cashcn.xyz/api/upload/media", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (isqr) {
          console.log(data.data.id);
        } else {
          console.log(data.data.id);
          console.log(data.data.path);
        }
      })
      .catch((error) => console.error(error));
  };

  return (
    <main>
      <form>
        <label class="custom-file-upload">
          <input type="file" onChange={(event) => handleFileUpload(event)} />
          <div className="title">
            <FiUploadCloud size="50px"  />
            <div className="container-text">
              <h3
                style={{
                  textAlign: "center",
                  fontFamily: "sans-serif",
                  marginBottom: "-10px",
                  color:"#745e5e"
                }}
              >
                Select a file or drag and drop here
              </h3>
              <h4 style={{ color: "gray", fontFamily: "sans-serif" ,fontSize:"13px",color:"#cfc8c8"}}> 
                JPG, PNG or PDF, file size no more than 10MB
              </h4>
             
            </div>
          </div>
        </label>
      </form>
    </main>
  );
}
