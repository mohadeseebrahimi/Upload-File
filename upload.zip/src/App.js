import Uploader from './components/Uploader/Uploader';
import './App.css';

function App() {
  return (
    <Uploader />
 
  )
}

export default App;
